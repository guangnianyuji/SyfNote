from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time
def login_test(contact,password):
    # 设置webdriver
    driver = webdriver.Chrome()

    # 打开Google首页
    driver.get("http://150.158.93.200:5672/login")
    driver.set_window_size(1176,732)
    time.sleep(2)
    # 找到搜索框
    contact_box = driver.find_element(By.XPATH, "//div[@id='app']/div[2]/div/div/form/div[2]/div/div/div/input")
    contact_box.send_keys(contact)

    password_box = driver.find_element(By.XPATH, "//div[@id='app']/div[2]/div/div/form/div[3]/div/div/div/input")
    password_box.send_keys(password)
    login_button= driver.find_element(By.CSS_SELECTOR,".loginButtonHolder span")
    login_button.click()
    # 等待几秒钟以便看到搜索结果
    time.sleep(1)
    elements = driver.find_elements(By.CSS_SELECTOR, '.el-menu-item:nth-child(1)')
    # 关闭浏览器
    #driver.quit()
    return elements is not None
def update_self_info_test(original_contact,password,name,contact):
    # 设置webdriver
    driver = webdriver.Chrome()
    driver.get("http://150.158.93.200:5672/login")
    driver.set_window_size(1176,732)
    time.sleep(2)
    # 找到搜索框
    contact_box = driver.find_element(By.XPATH, "//div[@id='app']/div[2]/div/div/form/div[2]/div/div/div/input")
    contact_box.send_keys(original_contact)

    password_box = driver.find_element(By.XPATH, "//div[@id='app']/div[2]/div/div/form/div[3]/div/div/div/input")
    password_box.send_keys(password)
    login_button= driver.find_element(By.CSS_SELECTOR,".loginButtonHolder span")
    login_button.click()
    # 等待几秒钟以便看到搜索结果
    #time.sleep(1)
    # 打开Google首页
    #driver.get("http://150.158.93.200:5672/adminiInfo")
    #driver.set_window_size(1176,732)
    time.sleep(2)
    # 找到搜索框
    edit_box = driver.find_element(By.XPATH, "//span[contains(.,'编辑')]")
    edit_box.click()
    name_box=driver.find_element(By.XPATH,"//div[@id='app']/div[2]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr/td[4]/div/div/input")
    name_box.clear()
    name_box.send_keys(name)
    contact_box = driver.find_element(By.XPATH, "//div[@id='app']/div[2]/div[2]/div[2]/div/div/div/div/div/div[2]/table/tbody/tr/td[6]/div/div/input")
    contact_box.clear()
    contact_box.send_keys(contact)
    save_button= driver.find_element(By.XPATH,"//span[contains(.,'保存')]")
    save_button.click()
    # 等待几秒钟以便看到搜索结果
    time.sleep(1)
    # 关闭浏览器
    driver.quit()
def update_doctor_info_test(original_contact,password,department):
    # 设置webdriver
    driver = webdriver.Chrome()
    driver.get("http://150.158.93.200:5672/login")
    driver.set_window_size(1176,732)
    time.sleep(2)
    # 找到搜索框
    contact_box = driver.find_element(By.XPATH, "//div[@id='app']/div[2]/div/div/form/div[2]/div/div/div/input")
    contact_box.send_keys(original_contact)

    password_box = driver.find_element(By.XPATH, "//div[@id='app']/div[2]/div/div/form/div[3]/div/div/div/input")
    password_box.send_keys(password)
    login_button= driver.find_element(By.CSS_SELECTOR,".loginButtonHolder span")
    login_button.click()
    time.sleep(5)
    # 等待几秒钟以便看到搜索结果
    censor_window = driver.find_element(By.XPATH,"//li[contains(.,'审核')]")
    censor_window.click()
    time.sleep(2)
    # 找到搜索框
    edit_box = driver.find_element(By.XPATH, "(//button[contains(.,'编辑')])[1]")
    edit_box.click()
    time.sleep(2)
    #Update Profile
    department_list = driver.find_element(By.XPATH,"/html/body/div[1]/div[2]/div[2]/div[2]/div[3]/div/div/div/form/div[5]/div/div/div/div/div/input")
    department_list.click()
    time.sleep(1)
    if department == '内分泌科':
        department_option = driver.find_element(By.XPATH,"/html/body/div[2]/div[5]/div/div/div[1]/ul/li[1]")
        department_option.click()
    else:
        department_option = driver.find_element(By.XPATH,"/html/body/div[2]/div[5]/div/div/div[1]/ul/li[2]")
        department_option.click()
    time.sleep(1)
    save_button= driver.find_element(By.XPATH,"//span[contains(.,'保存')]")
    save_button.click()
    # 等待几秒钟以便看到搜索结果
    time.sleep(1)
    # 关闭浏览器
    driver.quit()
def generate_invitation_code(contact,password,hospital_id):
    driver = webdriver.Chrome()
    driver.get("http://150.158.93.200:5672/login")
    driver.set_window_size(1176,732)
    time.sleep(2)
    # 找到搜索框
    contact_box = driver.find_element(By.XPATH, "//div[@id='app']/div[2]/div/div/form/div[2]/div/div/div/input")
    contact_box.send_keys(contact)

    password_box = driver.find_element(By.XPATH, "//div[@id='app']/div[2]/div/div/form/div[3]/div/div/div/input")
    password_box.send_keys(password)
    login_button= driver.find_element(By.CSS_SELECTOR,".loginButtonHolder span")
    login_button.click()
    time.sleep(5)

    invitation_button=driver.find_element(By.XPATH,'/html/body/div[1]/div[2]/div[1]/div[3]/div[1]/div')
    invitation_button.click()
    time.sleep(1)
    invitation_placeholder=driver.find_element(By.XPATH,"/html/body/div[1]/div[2]/div[1]/div[3]/div[2]/div/div/div/div/div/div/input")
    invitation_placeholder.click()
    time.sleep(1)
    invitation_placeholder.clear()
    invitation_placeholder.send_keys(hospital_id)
    time.sleep(1)
    invitation_save_button=driver.find_element(By.XPATH,"/html/body/div[1]/div[2]/div[1]/div[3]/div[2]/div/div/div/div[1]/button/span")
    invitation_save_button.click()
    time.sleep(2)
    invitation_code=driver.find_element(By.XPATH,"/html/body/div[1]/div[2]/div[1]/div[3]/div[2]/div/div/div/div[2]/strong").text
    print(invitation_code)
    cancel_button=driver.find_element(By.XPATH,"/html/body/div[1]/div[2]/div[1]/div[3]/div[2]/div/div/header/button")
    cancel_button.click()
    time.sleep(2)
    driver.quit()
    return invitation_code
def register(user_name,contact,password,code):
    driver = webdriver.Chrome()
    driver.get("http://150.158.93.200:5672/login")
    driver.set_window_size(1176,732)
    time.sleep(2)
    register_but=driver.find_element(By.XPATH,"/html/body/div[1]/div[2]/div/div/form/div[5]/a/button/span")
    register_but.click()
    time.sleep(2)
    username_but=driver.find_element(By.XPATH,"//div[@id='app']/div[2]/div/div/form/div[2]/div/div/div/input")
    username_but.click()
    username_but.send_keys(user_name)
    contact_but=driver.find_element(By.XPATH,"//div[@id='app']/div[2]/div/div/form/div[3]/div/div/div/input")
    contact_but.click()
    contact_but.send_keys(contact)
    passwd_but=driver.find_element(By.XPATH,"//div[@id='app']/div[2]/div/div/form/div[4]/div/div/div/input")
    passwd_but.click()
    passwd_but.send_keys(password)
    code_but=driver.find_element(By.XPATH,"//div[@id='app']/div[2]/div/div/form/div[5]/div/div/div/input")
    code_but.click()
    code_but.send_keys(code)
    register_but=driver.find_element(By.XPATH,"//button[contains(.,'注册')]")
    register_but.click()
    time.sleep(2)
    driver.quit()
if __name__=='__main__':
    #res=login_test('0216958120','190710')
    #print("Pass" if res else "Fail")
    #assert res,"Fail to login in"

    #update_self_info_test('0216958120','190710','Victor','0216958121')
    #update_self_info_test('0216958121','190710','Vict','0216958120')

    #update_doctor_info_test('0216958120','190710','内分泌科')
    #update_doctor_info_test('0216958120','190710','全科')
    code=generate_invitation_code('0216958120','190710',1)
    register('Vincent','13477776666','bfdbA120!',code)